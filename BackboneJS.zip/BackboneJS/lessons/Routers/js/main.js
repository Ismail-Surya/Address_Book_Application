let ArtistsView = Backbone.View.extend({

    render: function () {
        this.$el.html("ARTISTS VIEW")

        return this
    }

})

let AlbumsView = Backbone.View.extend({

    render: function () {
        this.$el.html("ALBUMS VIEW")

        return this
    }

})

let GenresView = Backbone.View.extend({

    render: function () {
        this.$el.html("GENRES VIEW")

        return this
    }

})

let AppRouter = Backbone.Router.extend({

    routes: {
        "albums" : "viewAlbums",
        "albums/:albumId" : "viewAlbumById",
        "artists" : "viewArtists",
        "genres" : "viewGenres",
        "*other" : "defaultRoute"
    },
    
    viewAlbumById: function (albumId) {

    },

    viewAlbums: function () {
        let view = new AlbumsView({ el: '#container' })

        view.render()
    },

    viewArtists: function() {
        let view = new ArtistsView({ el: '#container' })

        view.render()
    },

    viewGenres: function () {
        
        let view = new GenresView({ el: '#container' })

        view.render()

    },

    defaultRoute: function () {

    }

})

let router = new AppRouter()

Backbone.history.start()

let NavView = Backbone.View.extend({
    events: {
        "click" : "onClick"
    },
    onClick: function (e) {
        let $li = $(e.target)
        router.navigate($li.data("url"), { trigger: true })
    }
})

let navView = new NavView({ el: '#nav' })