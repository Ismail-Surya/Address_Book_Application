let Vehicle = Backbone.Model.extend();

let Vehicles = Backbone.Collection.extend({
    model: Vehicle
})

let car1 = new Vehicle({
    registrationNumber: 'XLI887',
    colour: 'Blue'
});

let car2 = new Vehicle({
    registrationNumber: 'ZNP123',
    colour: 'Blue'
});

let car3 = new Vehicle({
    registrationNumber: 'XUV456',
    colour: 'Grey'
});

let vehicles = new Vehicles([
    car1, car2, car3
])

console.table(vehicles.toJSON())

console.log(vehicles.get('c1').toJSON())

let blueVehicles = vehicles.where({colour: 'Blue'});

console.table(blueVehicles)