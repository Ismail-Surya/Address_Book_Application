var Song = Backbone.Model.extend()

var Songs = Backbone.Collection.extend({
    model: Song
})


var songs = new Songs([
    new Song({title: 'Kamikaze'}),
    new Song({title: 'Lucky You'}),
    new Song({title: 'Thinking out loud'})
])

songs.add(new Song({title: 'Killshot'}))

// To get an item from collection from a particular index

console.log(songs.at(0))

// To get an item from collection using cid

console.log(songs.get('c1'))

songs.remove(songs.at(0))

// This will add a song at the beginning of the collection

songs.add(new Song({title: 'Cindrella Man', Genre: 'Hip hop', downloads: 1000000}), { at:0 })

songs.push(new Song({title: 'Mockingbird', Genre: 'Hip hop',  downloads: 1000000}))

// Returns a collection of all Hip hop songs

let hipHopSongs = songs.where({Genre: 'Hip hop'})

console.log(hipHopSongs)

// Returns the first Hip hop song

let firstHipHopSong = songs.findWhere({Genre: 'Hip hop'})

console.log(firstHipHopSong)

let filteredSongs = songs.where({Genre: 'Hip hop', title: 'Mockingbird'})

console.log(filteredSongs)

let topDownloads = songs.filter(function (song) {
    return song.get("downloads") > 100
})

console.log(topDownloads)

songs.each(function (song) {
    console.log('Song - ',song)
})