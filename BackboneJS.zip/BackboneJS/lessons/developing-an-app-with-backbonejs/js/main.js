$(document).ready(function () {

    // $('body').css({ backgroundColor: 'black', color: 'white' })

    let todoItems = new TodoItems()

    todoItems.fetch({
        success: function () {
            
        }
    })

    let todoItemsView = new TodoItemsView({ model: todoItems })

    $('body').append(todoItemsView.render().$el)

    /* let todoItem = new TodoItem({ description : 'TodoItem 1' })

    let todoItemView = new TodoItemView({ model: todoItem })

    $('body').append(todoItemView.render().$el) */
})