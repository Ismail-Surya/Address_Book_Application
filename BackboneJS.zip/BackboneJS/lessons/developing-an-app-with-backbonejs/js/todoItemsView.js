let TodoItemsView = Backbone.View.extend({
    
    id: 'todoItemsContainer',

    initialize: function (options) {
        if (!(options && options.model))
            throw new Error('model is not specified.')

        this.model.on('add', this.onAddTodoItem, this)
        this.model.on('remove', this.onRemoveTodoItem, this)
    },
    
    onRemoveTodoItem: function (todoItem) {
        console.log('Removed', todoItem.toJSON())

        $('li#' + todoItem.id).remove()
    },
    
    onAddTodoItem: function (todoItem) {
        let view = new TodoItemView({ model: todoItem })
        this.$('#todoItems').prepend(view.render().$el)
        // this.$el.append(view.render().$el)
    },
    
    events: {
        // 'click #add': 'onClickAdd',
        'keypress #newTodoItem': 'onKeyPress'
    },
    
    onKeyPress: function (e) {
        if (e.keyCode == 13) {

            // this.onClickAdd()

            let $todoBox = this.$('#newTodoItem')

            if ($todoBox.val()) {

                let todoItem = new TodoItem({ title: $todoBox.val() })
                this.model.create(todoItem) // Replaces the commented code below

                /* todoItem.save()
                this.model.add(todoItem) */

                $todoBox.val('')

            }
        }
    },
    
    /* onClickAdd: function () {

        let $todoBox = this.$('#newTodoItem')

        if ($todoBox.val()) {

            let todoItem = new TodoItem({ title: $todoBox.val() })
            this.model.create(todoItem) // Replaces the commented code below

            todoItem.save()
            this.model.add(todoItem)

            $todoBox.val('')

        }
    }, */

    render: function () {

        let self = this

        let template = $('#todoItemsTemplate').html()

        let html = Mustache.render(template)

        this.$el.html(html)

        /* this.$el.append('<input type = "text" autofocus id = "newTodoItem"></input>')

        this.$el.append('<button id = "add">Add</button>')

        this.$el.append('<ul id = "todoItems"></ul>') */

        /* this.model.each(function (todoItem) {

            let view = new TodoItemView({ model: todoItem })

            self.$el.append(view.render().$el)

        }) */

        return this

    }

})