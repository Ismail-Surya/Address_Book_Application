/* class Song {
  persistFavoriteStatus(value) {
    // something complicated
    throw new Error('not yet implemented');
  }
} */

let Song = Backbone.Model.extend({
    urlRoot: '/api/songs',
    defaults: {
        numberOfPlays: 0
    },
    validate: function(attrs) {
        if (!attrs.title) {
            return "Title is required"
        }
    },
    play: function() {
        let numberOfPlays = this.get("numberOfPlays")
        this.set("numberOfPlays", numberOfPlays + 1)
    }
})