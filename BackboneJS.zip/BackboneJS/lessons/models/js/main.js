// Creating Models, working with its attributes and Validation

/* var Song = Backbone.Model.extend({

    // implementating validation in a model

    validate: function(attrs) {
        if (!attrs.title) {
            return "Title is required"
        }
    }
    ,
    defaults: {

        // while creating an object if we don't specify a genre
        // its value will be, by default, Jazz

        genre: 'Jazz'
    }
    ,
    initialize: function() {

        console.log('A new song has been created!')

    }
})

// set method sets an attribute for an object

var song = new Song({album: 'No album'});

song.set('title', 'Blue in Green')

song.set({
    artist: 'Miles Davis',
    publishYear: 1959
})

// get method gets an attribute from the object

console.log(song.get('title'))

// unset method removes the attribute from the object

song.unset('title')

console.log(song.get('title'))

// clear method removes all the attributes from the object

console.log('Before clear: ')
console.log(song.toJSON())
song.clear()
console.log('After clear: ')
console.log(song.toJSON())

// has method returns a boolean based on if an attribute is present in the model

console.log(song.has('title'))

// check if the object is valid

console.log(song.isValid())

// print out the error message

console.log(song.validationError) */

// Inheritance

/* var Animal = Backbone.Model.extend({
    walk: function () {
        console.log('Animal Walking ...')
    }
})

var Dog = Animal.extend({

    walk: function () {

        Animal.prototype.walk.apply(this)

        console.log('Dog walking ...')
    }

})

var dog = new Dog()

dog.walk() */

// Mini Project

Backbone.sync = function (method, model) {
    console.log(model)
}

let Todo = Backbone.Model.extend({

    url: 'https://www.jsonplaceholder.typicode.com/todos/',

    idAttribute: 'id'

})

let todo = new Todo({
    id: 1
})

todo.fetch({
    success: function () {
        console.log()
    }
})
