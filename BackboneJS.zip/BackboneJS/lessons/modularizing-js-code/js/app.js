define([
    'underscore',
    'backbone',
    'models/song',
    'views/songView'
], function(_, Backbone, Song, SongView) {

    let initialize = function() {
        let song = new Song({ title: 'Thinking out loud' })

        let songView = new SongView({ el: '#container', model: song })

        songView.render()
    }

    return {
        initialize: initialize
    }

})