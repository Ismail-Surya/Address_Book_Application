define([
    'underscore',
    'backbone'
    ], function (_, Backbone) {

    let Song = Backbone.Model.extend()

    return Song

})