let SongView = Backbone.View.extend({
    tagName: 'span',

    className: 'song',

    id: '1234',

    attributes: {
        'data-genre': 'Pop'
    },

    render: function () {
        this.$el.html('Hello, World!')
        return this
    }
})

let songView = new SongView()

$('#container').html(songView.render().$el)