let Song = Backbone.Model.extend({})

let Songs = Backbone.Collection.extend()

let song = new Song({
    title: 'Thinking out loud',
    artist: 'Ed Sheeran',
    downloads: 10000000
})

let songs = new Songs([
    song
])

let SongView = Backbone.View.extend({
    model: new Song(),
    tagName: 'tr',
    initialize: function () {
        this.template = _.template($('.songs-list-template').html())
    },
    render: function () {
        this.$el.html(this.template(this.model.toJSON()))
        return this
    }
})

let SongsView = Backbone.View.extend({
    model: songs,
    el: $('.songs-list'),
    initialize: function() {
        this.model.on('add', this.render, this)
    },
    render: function () {
        let self = this
        this.$el.html('')
        _.each(this.model.toArray(), function (song) {
            self.$el.append((new SongView({model: song})).render().$el)
        })
        return this
    }
})

let songsView = new SongsView()

let template = _.template($('.songs-list-template').html())

console.log(template(song.toJSON()))