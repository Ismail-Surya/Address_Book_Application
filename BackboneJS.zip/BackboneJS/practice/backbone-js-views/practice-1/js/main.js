/* let Song = Backbone.Model.extend({
    defaults: {
        listeners: 0
    }
})

let SongView = Backbone.View.extend({
    initialize: function() {
        this.model.on('change', this.onModelChange, this)
    },
    render: function () {
        this.$el.html(this.model.get('title') + ' - listeners: ' + this.model.get('listeners'))
        return this
    },
    onModelChange: function () {
        this.$el.animate({
            fontSize : this.model.get('listeners')
        })
    }
})

let song = new Song({ title: 'Thinking out loud' })

let songView = new SongView({ el: '#container', model: song })
songView.render() */


let Song = Backbone.Model.extend()

let Songs = Backbone.Collection.extend({
    model: Song
})

let SongView = Backbone.View.extend({
    events: {
        'click': 'onClick',
        'click .bookmark': 'onClickBookmark'
    },
    tagName: 'li',
    className: 'song',
    // id: '1234',
    attributes: {
        'data-genre': 'jazz'
    },
    render: function() {
        this.$el.html(this.model.get('title') + '<button>Listen</button><button class = "bookmark">Bookmark</button>')
        this.$el.attr('id', this.model.id)
        return this
    },
    onClick: function () {
        console.log('Listen Clicked')
    },
    onClickBookmark: function (e) {
        e.stopPropagation()
        console.log('Bookmark Clicked')
    }
})

let SongsView = Backbone.View.extend({
    el: '#container',
    initialize: function() {
        this.model.on('add', this.onSongAdded, this)
        this.model.on('remove', this.onSongRemoved, this)
    },
    render: function () {
        let self = this
        _.each(this.model.toArray(), function (song) {
            let songView = new SongView({ model: song })
            self.$el.append(songView.render().$el)
        })
        return this
    },
    onSongAdded: function (song) {
        let songView = new SongView( { model: song } )
        this.$el.append(songView.render().$el)
    },
    onSongRemoved: function (song) {
        this.$el.find('li#' + song.id).remove()
    }
})

let songs = new Songs([
    new Song({ id: 1, title: 'Mockingbird' }),
    new Song({ id: 2, title: 'Shape of You' }),
    new Song({ id: 3, title: 'Thinking out loud' })
])

let songsView = new SongsView({ model: songs })

songsView.render()