let Song = Backbone.Model.extend()

let SongView = Backbone.View.extend({

    events: {
        'click': 'onClick',
        'click .bookmark': 'onClickBookmark'
    },
    
    onClick: function() {
        console.log('Listen Clicked')
    },
    
    onClickBookmark: function(e) {
        e.stopPropagation()
        console.log('Bookmark Clicked')
    },

    render: function () {

        this.$el.html(this.model.get('title') + ' <button>Listen</button> <button class = "bookmark">Bookmark</button>')

        return this

    }

})

let song = new Song({ title: 'Thinking out loud' })

let songView = new SongView({ el: '#container', model: song })

songView.render()

/* let Song = Backbone.Model.extend()

let Songs = Backbone.Collection.extend({
    model: Song
})

let SongView = Backbone.View.extend({

    tagName: 'h3',
    
    className: 'badge badge-primary',
    
    attributes: {
        'data-genre' : 'Jazz'
    },
    
    id: 'heading',

    tagName: 'li',
    
    className: 'list-group-item',

    render : function() {

        this.$el.html(this.model.get('title'))

        return this

    }

})

let SongsView = Backbone.View.extend({

    render: function() {

        let self = this

        this.model.each(function(song) {

            let songView = new SongView({ model: song })

            self.$el.append(songView.render().$el)

        })

        return this
    }

})


let songs = new Songs([
    new Song({ title: 'Thinking out loud' }),
    new Song({ title: 'Kamikaze' }),
    new Song({ title: 'Lucky You' })
])

let songsView = new SongsView({ el: '#songs', model: songs })

songsView.render() */