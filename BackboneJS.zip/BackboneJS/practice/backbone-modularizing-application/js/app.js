define([
    'underscore',
    'backbone',
    'models/Instructor'
], function (_, Backbone, Instructor) {

    let initialize = function () {
        
        let instructor = new Instructor()

        console.log(instructor.toJSON())

    }

    return {
        initialize: initialize
    }

})