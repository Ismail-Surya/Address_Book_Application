define([
    'underscore',
    'backbone'
], function (_, Backbone) {

    let Instructor = Backbone.Model.extend({})

    return Instructor

})