let Song = Backbone.Model.extend({
    validate: function (attrs) {
        if (!attrs.length) {
            return "There is no length attribute"
        }
    },
    defaults: {
        singer: 'Eminem'
    },
    initialize: function () {
        // console.log('A song has been created')
    }
})

let Album = Backbone.Model.extend()

let album = new Album()

let kamikaze = new Song()

let luckyYou = new Song({
    title: 'Lucky You',
    length: 250
})

kamikaze.set({title : 'Kamikaze', length: 302})

console.log('Printing the first song -')

console.log(kamikaze.toJSON())

album.set({songs: [kamikaze, luckyYou]})

console.log('Printing objects in the Album -')

console.log(album.toJSON())

console.log('Printing the second song -')
console.log(album.get('songs')[1].toJSON())

let luckyYou2 = album.get('songs')[1]

luckyYou2.unset('length')

console.log(luckyYou.toJSON())

console.log('Lucky you doesn\'t have a length anymore -')

console.log('Has length = ' + luckyYou.has('length'))

console.log('Is it valid anymore')

console.log(luckyYou2.isValid())

console.log('The validation error -')

console.log(luckyYou2.validationError)