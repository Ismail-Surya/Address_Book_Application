let person = {
    name : 'Mosh',
    walk: function () {
        this.trigger('walking', {
            speed: 1,
            startTime: '08:00'
        })
    }
}

_.extend(person, Backbone.Events)

person.once('walking', function (e) {
    console.log(this.name, 'is walking')
    console.log('Event Args', e)
})

// person.off('walking')

person.walk()

person.walk()