let person = {
    name: 'Ismail',

    walk: function () {
        this.trigger("walking", {
            speed: 1,
            startTime: "08:00"
        })
    }
}

_.extend(person, Backbone.Events)

person.once("walking", function (e) {
    console.log("Person is walking")
    console.log("Event Args", e)
})

// person.off("walking")

person.walk()

let songs = {
    songList : ['Thinking out loud', 'Shape of You'],
    list: function () {
        this.trigger("listSongs")
    }
}

_.extend(songs, Backbone.Events)

songs.on("listSongs", function () {
    for (let song of this.songList) {
        console.log(song)
    }
})

songs.list()