let  AppRouter = Backbone.Router.extend({

    routes : {
        'home': 'homeNav',
        'products' : 'productsView',
        'about' : 'aboutView'
    },

    homeNav: function () {
        console.log('Home View')
    },

    productsView: function () {
        console.log('Products View')
    },

    aboutView: function () {
        console.log('About View')
    }

})

let router = new AppRouter()

Backbone.history.start()

let NavView = Backbone.View.extend({

    events: {
        'click' : 'onClick'
    },

    onClick: function (e) {
        
        $a = $(e.target)

        router.navigate($a.data('url'), { trigger: true })

    }

})

let navView = new NavView( { el: '.navbar' } )

let obj = {
    data: [ 'Java', 'Python', 'JavaScript', 'Ruby', 'PHP' ],
    list: function () {
        this.trigger('listing')
    }
}

_.extend(obj, Backbone.Events)

obj.on('listing', function (e) {
    for (let datum of this.data) {
        console.log(datum)
    }
    console.log('Event args', e)
})