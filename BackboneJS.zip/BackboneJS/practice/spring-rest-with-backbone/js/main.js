let Product = Backbone.Model.extend()

let Products = Backbone.Collection.extend({
    url: 'http://localhost:8080/spring-rest-service-based-on-course/api/products'
})

let products = new Products()

products.fetch()

let ProductView = Backbone.View.extend({
    tagName: 'li',
    className: 'list-group-item',
    render: function () {
        let template = _.template($('#productTemplate').html())
        let html = template(this.model.toJSON())
        this.$el.html(html)
        return this
    }
})

let ProductsView = Backbone.View.extend({
    model: products,
    el: '#list',
    initialize: function () {
        this.model.on('add', this.render, this)
    },
    render: function () {
        let self = this
        this.$el.empty()
        _.each(this.model.toArray(), function (product) {
            self.$el.append((new ProductView({ model: product })).render().$el)
        })
    }
})

let productsView = new ProductsView()