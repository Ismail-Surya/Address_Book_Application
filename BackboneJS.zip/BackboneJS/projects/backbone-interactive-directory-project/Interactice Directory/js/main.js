
// In the first few sections, we do all the coding here.
// Later, you'll see how to organize your code into separate
// files and modules.

let V = Backbone.View.extend({
    el: '#wrapper',

    events: {

        'keyup #searchBox': 'showAlert'

    },

    initialize: function () {
        this.on('change:searchBox', this.showAlert2, this)
    },

    showAlert: function () {
        this.trigger('change:searchBox')
        this.searchBox = '1'
    },

    showAlert2: function () {
        alert(4)
    }

})

// let v = new V()