backbone-interactive-directory
==============================

Check out the video of how this works on Youtube: http://www.youtube.com/watch?v=T4iPnh-qago
