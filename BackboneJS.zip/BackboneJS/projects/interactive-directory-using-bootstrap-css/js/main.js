directoryData = [
	{
		"ID": "1",
		"firstname": "Brody",
		"lastname": "Kim",
		"email": "sit.amet.orci@sem.com",
		"homephone": "1-012-354-2647",
		"parent": ""
	},
	{
		"ID": "2",
		"firstname": "Shellie",
		"lastname": "Dickerson",
		"email": "mattis.Integer@Mauris.ca",
		"homephone": "1-933-632-7812",
		"parent": ""
	},
	{
		"ID": "3",
		"firstname": "Kay",
		"lastname": "Johnson",
		"email": "mus@Seddiamlorem.com",
		"homephone": "1-258-737-5533",
		"parent": ""
	},
	{
		"ID": "4",
		"firstname": "Lesley",
		"lastname": "Walls",
		"email": "felis.adipiscing@dictum.com",
		"homephone": "1-591-621-1728",
		"parent": ""
	},
	{
		"ID": "5",
		"firstname": "Lois",
		"lastname": "Armstrong",
		"email": "eu.eleifend.nec@vitaesemperegestas.ca",
		"homephone": "1-690-936-5215",
		"parent": ""
	},
	{
		"ID": "6",
		"firstname": "Garth",
		"lastname": "Rosa",
		"email": "diam@disparturientmontes.ca",
		"homephone": "1-082-367-9641",
		"parent": ""
	},
	{
		"ID": "7",
		"firstname": "Silas",
		"lastname": "Mckinney",
		"email": "pede@tempuseu.edu",
		"homephone": "1-373-528-8081",
		"parent": ""
	},
	{
		"ID": "8",
		"firstname": "Karly",
		"lastname": "Noble",
		"email": "Cum@turpisNullaaliquet.co.uk",
		"homephone": "1-635-241-0038",
		"parent": ""
	},
	{
		"ID": "9",
		"firstname": "Kyle",
		"lastname": "Warren",
		"email": "at.velit.Pellentesque@felis.ca",
		"homephone": "1-127-137-5088",
		"parent": ""
	},
	{
		"ID": "10",
		"firstname": "Cruz",
		"lastname": "Serrano",
		"email": "enim.Sed.nulla@utipsum.co.uk",
		"homephone": "1-589-966-4568",
		"parent": ""
	},
	{
		"ID": "11",
		"firstname": "August",
		"lastname": "Hubbard",
		"email": "dis@Donec.net",
		"homephone": "1-967-757-9335",
		"parent": ""
	},
	{
		"ID": "12",
		"firstname": "Colt",
		"lastname": "Juarez",
		"email": "sed.sapien@placerataugue.net",
		"homephone": "1-172-751-8921",
		"parent": ""
	},
	{
		"ID": "13",
		"firstname": "Hilary",
		"lastname": "Small",
		"email": "Nam@Aliquamfringilla.ca",
		"homephone": "1-380-738-9829",
		"parent": ""
	},
	{
		"ID": "14",
		"firstname": "Jena",
		"lastname": "Noble",
		"email": "eleifend.nec@mauriselitdictum.net",
		"homephone": "1-106-418-8099",
		"parent": ""
	},
	{
		"ID": "15",
		"firstname": "Quincy",
		"lastname": "Matthews",
		"email": "Proin.non.massa@montesnascetur.co.uk",
		"homephone": "1-458-751-1253",
		"parent": ""
	},
	{
		"ID": "16",
		"firstname": "Rae",
		"lastname": "Benjamin",
		"email": "Lorem.ipsum@odioEtiamligula.co.uk",
		"homephone": "1-569-555-2048",
		"parent": ""
	},
	{
		"ID": "17",
		"firstname": "Caleb",
		"lastname": "Sears",
		"email": "posuere@consectetueripsumnunc.com",
		"homephone": "1-805-447-1509",
		"parent": ""
	},
	{
		"ID": "18",
		"firstname": "Serena",
		"lastname": "Vazquez",
		"email": "nulla.Cras.eu@augueSedmolestie.co.uk",
		"homephone": "1-440-937-0198",
		"parent": ""
	},
	{
		"ID": "19",
		"firstname": "Thomas",
		"lastname": "Burgess",
		"email": "elit.Aliquam@odioNam.org",
		"homephone": "1-329-421-2197",
		"parent": ""
	},
	{
		"ID": "20",
		"firstname": "Conan",
		"lastname": "Pate",
		"email": "arcu.ac@accumsanconvallisante.edu",
		"homephone": "1-552-630-4464",
		"parent": ""
	},
	{
		"ID": "21",
		"firstname": "Rafael",
		"lastname": "Tyler",
		"email": "dapibus.quam@nonummyacfeugiat.com",
		"homephone": "1-025-995-2619",
		"parent": ""
	},
	{
		"ID": "22",
		"firstname": "Kylie",
		"lastname": "Welch",
		"email": "ullamcorper@suscipit.org",
		"homephone": "1-109-851-6467",
		"parent": ""
	},
	{
		"ID": "23",
		"firstname": "Leonard",
		"lastname": "Barron",
		"email": "pede.Cras@duisemper.net",
		"homephone": "1-154-348-8489",
		"parent": ""
	},
	{
		"ID": "24",
		"firstname": "Jonah",
		"lastname": "Hess",
		"email": "Donec.porttitor.tellus@pedenec.edu",
		"homephone": "1-535-209-7025",
		"parent": ""
	},
	{
		"ID": "25",
		"firstname": "Luke",
		"lastname": "Gordon",
		"email": "Mauris.blandit.enim@massarutrummagna.ca",
		"homephone": "1-680-576-0146",
		"parent": ""
	},
	{
		"ID": "26",
		"firstname": "Bethany",
		"lastname": "Pruitt",
		"email": "elit@liberoat.org",
		"homephone": "1-205-561-1993",
		"parent": ""
	},
	{
		"ID": "27",
		"firstname": "Yoko",
		"lastname": "Warner",
		"email": "elit.fermentum@dolor.ca",
		"homephone": "1-607-263-2346",
		"parent": ""
	},
	{
		"ID": "28",
		"firstname": "Nissim",
		"lastname": "Bright",
		"email": "facilisis.lorem.tristique@etrutrum.org",
		"homephone": "1-864-791-7865",
		"parent": ""
	},
	{
		"ID": "29",
		"firstname": "Madeson",
		"lastname": "Burch",
		"email": "nascetur.ridiculus@urnaNuncquis.com",
		"homephone": "1-196-653-2630",
		"parent": ""
	},
	{
		"ID": "30",
		"firstname": "Stephen",
		"lastname": "Humphrey",
		"email": "nisi@consectetueripsumnunc.org",
		"homephone": "1-063-722-3389",
		"parent": ""
	},
	{
		"ID": "31",
		"firstname": "Lael",
		"lastname": "Ellison",
		"email": "ultrices@euismodetcommodo.edu",
		"homephone": "1-317-721-5620",
		"parent": ""
	},
	{
		"ID": "32",
		"firstname": "Calvin",
		"lastname": "Long",
		"email": "nonummy.ultricies@adipiscingligulaAenean.edu",
		"homephone": "1-163-165-5880",
		"parent": ""
	},
	{
		"ID": "33",
		"firstname": "Orson",
		"lastname": "Cline",
		"email": "erat@eutemporerat.edu",
		"homephone": "1-047-343-4092",
		"parent": ""
	},
	{
		"ID": "34",
		"firstname": "Doris",
		"lastname": "Ferrell",
		"email": "lectus@ametrisus.ca",
		"homephone": "1-164-972-7946",
		"parent": ""
	},
	{
		"ID": "35",
		"firstname": "Drake",
		"lastname": "Prince",
		"email": "parturient.montes.nascetur@Aliquamornare.edu",
		"homephone": "1-871-801-0310",
		"parent": ""
	},
	{
		"ID": "36",
		"firstname": "Elmo",
		"lastname": "Mccall",
		"email": "nec@mollis.net",
		"homephone": "1-377-736-0157",
		"parent": ""
	},
	{
		"ID": "37",
		"firstname": "Sylvia",
		"lastname": "Stanley",
		"email": "dolor.tempus@diam.ca",
		"homephone": "1-149-448-6096",
		"parent": ""
	},
	{
		"ID": "38",
		"firstname": "Adele",
		"lastname": "Hammond",
		"email": "eget.venenatis@enim.com",
		"homephone": "1-613-389-1758",
		"parent": ""
	},
	{
		"ID": "39",
		"firstname": "Stuart",
		"lastname": "Irwin",
		"email": "nec.ligula.consectetuer@pharetraQuisque.net",
		"homephone": "1-398-369-2040",
		"parent": ""
	},
	{
		"ID": "40",
		"firstname": "Kuame",
		"lastname": "Dejesus",
		"email": "tincidunt.Donec.vitae@turpisegestas.ca",
		"homephone": "1-523-101-8512",
		"parent": ""
	},
	{
		"ID": "41",
		"firstname": "Jena",
		"lastname": "Berger",
		"email": "magna@Etiamgravidamolestie.edu",
		"homephone": "1-980-481-9196",
		"parent": ""
	},
	{
		"ID": "42",
		"firstname": "Allen",
		"lastname": "Elliott",
		"email": "egestas@enimconsequat.org",
		"homephone": "1-708-937-3308",
		"parent": ""
	},
	{
		"ID": "43",
		"firstname": "Lenore",
		"lastname": "Weeks",
		"email": "Sed@penatibus.com",
		"homephone": "1-253-220-2415",
		"parent": ""
	},
	{
		"ID": "44",
		"firstname": "Finn",
		"lastname": "Sloan",
		"email": "varius.Nam.porttitor@elitelitfermentum.net",
		"homephone": "1-520-603-1065",
		"parent": ""
	},
	{
		"ID": "45",
		"firstname": "Forrest",
		"lastname": "Savage",
		"email": "pede@parturient.edu",
		"homephone": "1-175-426-6150",
		"parent": ""
	},
	{
		"ID": "46",
		"firstname": "Guy",
		"lastname": "Ramos",
		"email": "hendrerit.Donec@nequeetnunc.ca",
		"homephone": "1-206-867-2401",
		"parent": ""
	},
	{
		"ID": "47",
		"firstname": "Lance",
		"lastname": "Cooley",
		"email": "ridiculus.mus.Proin@euodioPhasellus.ca",
		"homephone": "1-487-185-3699",
		"parent": ""
	},
	{
		"ID": "48",
		"firstname": "Shannon",
		"lastname": "Mcdaniel",
		"email": "tortor.at@luctus.ca",
		"homephone": "1-979-186-6049",
		"parent": ""
	},
	{
		"ID": "49",
		"firstname": "Lucas",
		"lastname": "Lucas",
		"email": "eu@arcu.org",
		"homephone": "1-869-864-6215",
		"parent": ""
	},
	{
		"ID": "50",
		"firstname": "Megan",
		"lastname": "Bullock",
		"email": "dolor.elit@lobortis.com",
		"homephone": "1-603-201-7541",
		"parent": ""
	},
	{
		"ID": "51",
		"firstname": "Quyn",
		"lastname": "Lopez",
		"email": "tellus.eu.augue@Craseget.edu",
		"homephone": "1-923-177-7921",
		"parent": ""
	},
	{
		"ID": "52",
		"firstname": "Nigel",
		"lastname": "Irwin",
		"email": "et.tristique.pellentesque@aliquamiaculislacus.net",
		"homephone": "1-953-572-2396",
		"parent": ""
	},
	{
		"ID": "53",
		"firstname": "Keaton",
		"lastname": "Rivers",
		"email": "lacinia.Sed.congue@pede.ca",
		"homephone": "1-874-184-7315",
		"parent": ""
	},
	{
		"ID": "54",
		"firstname": "Adria",
		"lastname": "Hanson",
		"email": "eu@Crasdolordolor.org",
		"homephone": "1-986-955-4332",
		"parent": ""
	},
	{
		"ID": "55",
		"firstname": "Fleur",
		"lastname": "Robbins",
		"email": "dolor@felis.co.uk",
		"homephone": "1-713-874-8164",
		"parent": ""
	},
	{
		"ID": "56",
		"firstname": "Elijah",
		"lastname": "Shields",
		"email": "eu.nulla.at@Inat.net",
		"homephone": "1-030-454-7377",
		"parent": ""
	},
	{
		"ID": "57",
		"firstname": "Brian",
		"lastname": "Pickett",
		"email": "ornare@semper.co.uk",
		"homephone": "1-501-259-4386",
		"parent": ""
	},
	{
		"ID": "58",
		"firstname": "Marsden",
		"lastname": "Goff",
		"email": "leo.Vivamus.nibh@musProin.org",
		"homephone": "1-807-683-7550",
		"parent": ""
	},
	{
		"ID": "59",
		"firstname": "Odessa",
		"lastname": "Beck",
		"email": "vitae@a.com",
		"homephone": "1-175-934-6735",
		"parent": ""
	},
	{
		"ID": "60",
		"firstname": "Nehru",
		"lastname": "Barlow",
		"email": "ligula@orciconsectetuereuismod.ca",
		"homephone": "1-142-758-4602",
		"parent": ""
	},
	{
		"ID": "61",
		"firstname": "Ezekiel",
		"lastname": "Hurst",
		"email": "semper.cursus.Integer@ultricies.org",
		"homephone": "1-541-803-5033",
		"parent": ""
	},
	{
		"ID": "62",
		"firstname": "Basia",
		"lastname": "Wolfe",
		"email": "ante@lorem.edu",
		"homephone": "1-037-155-3944",
		"parent": ""
	},
	{
		"ID": "63",
		"firstname": "Emily",
		"lastname": "Wallace",
		"email": "Duis.a@vehicula.co.uk",
		"homephone": "1-499-838-9395",
		"parent": ""
	},
	{
		"ID": "64",
		"firstname": "Rebekah",
		"lastname": "Newton",
		"email": "sit.amet@Nunccommodo.ca",
		"homephone": "1-906-356-6414",
		"parent": ""
	},
	{
		"ID": "65",
		"firstname": "Lucius",
		"lastname": "Ewing",
		"email": "eu@elit.co.uk",
		"homephone": "1-192-147-8139",
		"parent": ""
	},
	{
		"ID": "66",
		"firstname": "Allen",
		"lastname": "Martinez",
		"email": "vulputate.ullamcorper@scelerisque.net",
		"homephone": "1-831-177-6082",
		"parent": ""
	},
	{
		"ID": "67",
		"firstname": "Savannah",
		"lastname": "Calderon",
		"email": "Sed.congue@adipiscingnon.com",
		"homephone": "1-023-428-4825",
		"parent": ""
	},
	{
		"ID": "68",
		"firstname": "Xena",
		"lastname": "Dunn",
		"email": "vel.arcu.eu@mieleifend.edu",
		"homephone": "1-141-164-9786",
		"parent": ""
	},
	{
		"ID": "69",
		"firstname": "Erasmus",
		"lastname": "Sheppard",
		"email": "tincidunt@et.net",
		"homephone": "1-916-276-1044",
		"parent": ""
	},
	{
		"ID": "70",
		"firstname": "Daria",
		"lastname": "Mcpherson",
		"email": "eu.neque@necquamCurabitur.org",
		"homephone": "1-251-223-4050",
		"parent": ""
	},
	{
		"ID": "71",
		"firstname": "Craig",
		"lastname": "Sheppard",
		"email": "ligula@dignissimlacus.edu",
		"homephone": "1-051-505-7614",
		"parent": ""
	},
	{
		"ID": "72",
		"firstname": "Roth",
		"lastname": "Sanchez",
		"email": "Maecenas.malesuada@loremtristiquealiquet.ca",
		"homephone": "1-216-818-0004",
		"parent": ""
	},
	{
		"ID": "73",
		"firstname": "Hedwig",
		"lastname": "Lopez",
		"email": "nisi.sem@dolorDonec.co.uk",
		"homephone": "1-185-439-1155",
		"parent": ""
	},
	{
		"ID": "74",
		"firstname": "Garrison",
		"lastname": "Chandler",
		"email": "Proin.vel@elitNullafacilisi.net",
		"homephone": "1-727-762-1280",
		"parent": ""
	},
	{
		"ID": "75",
		"firstname": "Zachery",
		"lastname": "Wiley",
		"email": "nunc@lectusquis.com",
		"homephone": "1-453-914-3288",
		"parent": ""
	},
	{
		"ID": "76",
		"firstname": "Ashely",
		"lastname": "Maldonado",
		"email": "dis.parturient.montes@dui.edu",
		"homephone": "1-572-481-4822",
		"parent": ""
	},
	{
		"ID": "77",
		"firstname": "Mariam",
		"lastname": "Kane",
		"email": "arcu.Vestibulum.ante@nasceturridiculusmus.org",
		"homephone": "1-396-287-2365",
		"parent": ""
	},
	{
		"ID": "78",
		"firstname": "Dominic",
		"lastname": "Massey",
		"email": "libero@massalobortisultrices.co.uk",
		"homephone": "1-917-230-7870",
		"parent": ""
	},
	{
		"ID": "79",
		"firstname": "Iliana",
		"lastname": "Guzman",
		"email": "bibendum@vel.com",
		"homephone": "1-836-593-7567",
		"parent": ""
	},
	{
		"ID": "80",
		"firstname": "Forrest",
		"lastname": "Ortiz",
		"email": "consequat@vehiculaaliquet.net",
		"homephone": "1-427-224-6540",
		"parent": ""
	},
	{
		"ID": "81",
		"firstname": "Lysandra",
		"lastname": "Francis",
		"email": "lacus.Quisque@vulputatenisisem.co.uk",
		"homephone": "1-364-948-2107",
		"parent": ""
	},
	{
		"ID": "82",
		"firstname": "Kamal",
		"lastname": "Manning",
		"email": "quam.dignissim.pharetra@at.co.uk",
		"homephone": "1-675-281-7157",
		"parent": ""
	},
	{
		"ID": "83",
		"firstname": "Jordan",
		"lastname": "Pratt",
		"email": "lorem.vitae@Cras.ca",
		"homephone": "1-076-242-6013",
		"parent": ""
	},
	{
		"ID": "84",
		"firstname": "Graham",
		"lastname": "Fulton",
		"email": "non.enim.Mauris@necenimNunc.co.uk",
		"homephone": "1-981-662-0362",
		"parent": ""
	},
	{
		"ID": "85",
		"firstname": "Berk",
		"lastname": "Richard",
		"email": "risus.at@elitfermentum.com",
		"homephone": "1-642-885-1143",
		"parent": ""
	},
	{
		"ID": "86",
		"firstname": "Levi",
		"lastname": "Gallegos",
		"email": "sit@bibendumullamcorper.edu",
		"homephone": "1-664-490-4662",
		"parent": ""
	},
	{
		"ID": "87",
		"firstname": "Jerome",
		"lastname": "Little",
		"email": "diam.nunc.ullamcorper@dictumauguemalesuada.net",
		"homephone": "1-379-800-4308",
		"parent": ""
	},
	{
		"ID": "88",
		"firstname": "May",
		"lastname": "Velasquez",
		"email": "rutrum.lorem@accumsanneque.com",
		"homephone": "1-339-160-5274",
		"parent": ""
	},
	{
		"ID": "89",
		"firstname": "Gareth",
		"lastname": "Ferrell",
		"email": "a@Donec.edu",
		"homephone": "1-255-343-9393",
		"parent": ""
	},
	{
		"ID": "90",
		"firstname": "Sara",
		"lastname": "Mckay",
		"email": "Mauris@metusIn.co.uk",
		"homephone": "1-560-401-6347",
		"parent": ""
	},
	{
		"ID": "91",
		"firstname": "Lacota",
		"lastname": "Vargas",
		"email": "odio.Aliquam.vulputate@molestieSed.ca",
		"homephone": "1-828-755-5158",
		"parent": ""
	},
	{
		"ID": "92",
		"firstname": "Mira",
		"lastname": "Page",
		"email": "mauris@parturientmontesnascetur.org",
		"homephone": "1-937-313-8020",
		"parent": ""
	},
	{
		"ID": "93",
		"firstname": "Kelsey",
		"lastname": "Levine",
		"email": "dictum.eu@ametrisus.org",
		"homephone": "1-965-542-1154",
		"parent": ""
	},
	{
		"ID": "94",
		"firstname": "Chastity",
		"lastname": "Schmidt",
		"email": "sagittis.placerat.Cras@luctuset.ca",
		"homephone": "1-816-211-7654",
		"parent": ""
	},
	{
		"ID": "95",
		"firstname": "Maia",
		"lastname": "Skinner",
		"email": "facilisis.eget.ipsum@sagittislobortis.net",
		"homephone": "1-660-210-3999",
		"parent": ""
	},
	{
		"ID": "96",
		"firstname": "Cadman",
		"lastname": "Maldonado",
		"email": "hymenaeos.Mauris@commodo.org",
		"homephone": "1-420-971-6619",
		"parent": ""
	},
	{
		"ID": "97",
		"firstname": "Len",
		"lastname": "Pratt",
		"email": "lorem.lorem@metusInlorem.org",
		"homephone": "1-723-718-8620",
		"parent": ""
	},
	{
		"ID": "98",
		"firstname": "Quynn",
		"lastname": "Kelly",
		"email": "Phasellus.dapibus@tristiquepharetra.co.uk",
		"homephone": "1-794-884-3616",
		"parent": ""
	},
	{
		"ID": "99",
		"firstname": "Yasir",
		"lastname": "Andrews",
		"email": "augue@risusDuis.com",
		"homephone": "1-169-478-1121",
		"parent": ""
	},
	{
		"ID": "100",
		"firstname": "Kirsten",
		"lastname": "Atkinson",
		"email": "urna.nec@Infaucibus.org",
		"homephone": "1-969-233-0342",
		"parent": ""
	},
	{
			"ID": "1",
			"firstname": "Dalton",
			"lastname": "Macdonald",
			"email": "et.netus.et@molestiesodales.ca",
			"homephone": "1-327-645-1496",
			"parent": "99"
		},
		{
			"ID": "2",
			"firstname": "Dean",
			"lastname": "Wolfe",
			"email": "ac.sem.ut@Aliquamultricesiaculis.com",
			"homephone": "1-215-742-9007",
			"parent": "50"
		},
		{
			"ID": "3",
			"firstname": "Cleo",
			"lastname": "Gentry",
			"email": "nec.luctus.felis@bibendum.co.uk",
			"homephone": "1-554-614-8147",
			"parent": "11"
		},
		{
			"ID": "4",
			"firstname": "Joy",
			"lastname": "Wiley",
			"email": "lectus.Cum@morbitristique.edu",
			"homephone": "1-791-876-0145",
			"parent": "20"
		},
		{
			"ID": "5",
			"firstname": "Tanya",
			"lastname": "Jensen",
			"email": "felis.orci.adipiscing@MorbimetusVivamus.ca",
			"homephone": "1-317-898-3829",
			"parent": "42"
		},
		{
			"ID": "6",
			"firstname": "Ezra",
			"lastname": "Bruce",
			"email": "pede@nec.edu",
			"homephone": "1-891-343-2916",
			"parent": "91"
		},
		{
			"ID": "7",
			"firstname": "Keefe",
			"lastname": "Faulkner",
			"email": "nibh@Sed.ca",
			"homephone": "1-945-249-5508",
			"parent": "75"
		},
		{
			"ID": "8",
			"firstname": "Asher",
			"lastname": "Terry",
			"email": "eu.accumsan@gravida.ca",
			"homephone": "1-415-674-1078",
			"parent": "14"
		},
		{
			"ID": "9",
			"firstname": "Scarlet",
			"lastname": "Kinney",
			"email": "risus@sapien.ca",
			"homephone": "1-971-159-0451",
			"parent": "58"
		},
		{
			"ID": "10",
			"firstname": "Ivana",
			"lastname": "Oneill",
			"email": "cursus@urna.org",
			"homephone": "1-684-475-1264",
			"parent": "29"
		},
		{
			"ID": "11",
			"firstname": "Wang",
			"lastname": "Bright",
			"email": "condimentum@nonummy.com",
			"homephone": "1-237-743-1147",
			"parent": "34"
		},
		{
			"ID": "12",
			"firstname": "Brooke",
			"lastname": "Carr",
			"email": "Cras.convallis.convallis@aauctor.net",
			"homephone": "1-240-893-8055",
			"parent": "32"
		},
		{
			"ID": "13",
			"firstname": "Ria",
			"lastname": "Solis",
			"email": "dui.Cras@quisdiam.ca",
			"homephone": "1-046-420-5395",
			"parent": "96"
		},
		{
			"ID": "14",
			"firstname": "Evangeline",
			"lastname": "Hart",
			"email": "mi@sedsapien.net",
			"homephone": "1-887-440-2263",
			"parent": "94"
		},
		{
			"ID": "15",
			"firstname": "Simon",
			"lastname": "Tucker",
			"email": "justo.eu.arcu@nisiMauris.ca",
			"homephone": "1-698-658-9997",
			"parent": "40"
		},
		{
			"ID": "16",
			"firstname": "Alea",
			"lastname": "Johnson",
			"email": "laoreet@Nulla.com",
			"homephone": "1-396-925-7140",
			"parent": "80"
		},
		{
			"ID": "17",
			"firstname": "Shea",
			"lastname": "Mccullough",
			"email": "amet.consectetuer@Nullamut.com",
			"homephone": "1-202-376-2281",
			"parent": "50"
		},
		{
			"ID": "18",
			"firstname": "Lael",
			"lastname": "Juarez",
			"email": "nec.luctus.felis@congue.net",
			"homephone": "1-659-167-9117",
			"parent": "65"
		},
		{
			"ID": "19",
			"firstname": "Derek",
			"lastname": "Bean",
			"email": "Morbi.non.sapien@enim.edu",
			"homephone": "1-843-757-3068",
			"parent": "15"
		},
		{
			"ID": "20",
			"firstname": "Geraldine",
			"lastname": "Melton",
			"email": "Aliquam.erat.volutpat@lacusvarius.org",
			"homephone": "1-386-563-7620",
			"parent": "94"
		},
		{
			"ID": "21",
			"firstname": "Griffith",
			"lastname": "Buckner",
			"email": "ligula.tortor.dictum@sitamet.org",
			"homephone": "1-294-875-1430",
			"parent": "99"
		},
		{
			"ID": "22",
			"firstname": "Cyrus",
			"lastname": "Levy",
			"email": "arcu@porta.net",
			"homephone": "1-563-762-1718",
			"parent": "20"
		},
		{
			"ID": "23",
			"firstname": "Nina",
			"lastname": "Dominguez",
			"email": "bibendum.fermentum@posuereat.org",
			"homephone": "1-248-548-7018",
			"parent": "23"
		},
		{
			"ID": "24",
			"firstname": "Yetta",
			"lastname": "Lindsey",
			"email": "Nunc.mauris.sapien@dolorFuscemi.com",
			"homephone": "1-160-352-9766",
			"parent": "42"
		},
		{
			"ID": "25",
			"firstname": "Tanek",
			"lastname": "Beasley",
			"email": "ornare.facilisis@eunullaat.net",
			"homephone": "1-798-970-8374",
			"parent": "20"
		},
		{
			"ID": "26",
			"firstname": "Ebony",
			"lastname": "Parsons",
			"email": "sem.semper@cursusetmagna.org",
			"homephone": "1-951-615-4228",
			"parent": "12"
		},
		{
			"ID": "27",
			"firstname": "Hannah",
			"lastname": "Mcpherson",
			"email": "condimentum.eget.volutpat@mauriserat.edu",
			"homephone": "1-464-306-5794",
			"parent": "53"
		},
		{
			"ID": "28",
			"firstname": "Kristen",
			"lastname": "Shaw",
			"email": "arcu.Vivamus@orci.com",
			"homephone": "1-654-845-2045",
			"parent": "44"
		},
		{
			"ID": "29",
			"firstname": "Casey",
			"lastname": "Moon",
			"email": "vitae.risus.Duis@a.co.uk",
			"homephone": "1-666-601-2863",
			"parent": "90"
		},
		{
			"ID": "30",
			"firstname": "Quyn",
			"lastname": "Malone",
			"email": "iaculis.aliquet@dignissim.net",
			"homephone": "1-557-912-1719",
			"parent": "81"
		},
		{
			"ID": "31",
			"firstname": "Cody",
			"lastname": "Savage",
			"email": "tellus.lorem@enimMauris.co.uk",
			"homephone": "1-637-466-1215",
			"parent": "26"
		},
		{
			"ID": "32",
			"firstname": "Jordan",
			"lastname": "Estrada",
			"email": "quis.diam.Pellentesque@Etiam.edu",
			"homephone": "1-299-487-5614",
			"parent": "18"
		},
		{
			"ID": "33",
			"firstname": "Germane",
			"lastname": "Fischer",
			"email": "primis.in.faucibus@ornare.org",
			"homephone": "1-636-889-2173",
			"parent": "22"
		},
		{
			"ID": "34",
			"firstname": "Katelyn",
			"lastname": "Landry",
			"email": "nulla.Cras@Duisvolutpat.com",
			"homephone": "1-140-381-6103",
			"parent": "20"
		},
		{
			"ID": "35",
			"firstname": "Echo",
			"lastname": "Santiago",
			"email": "sed.pede.nec@Aeneaneget.ca",
			"homephone": "1-496-229-6831",
			"parent": "24"
		},
		{
			"ID": "36",
			"firstname": "Devin",
			"lastname": "Holder",
			"email": "at.arcu@ultriciessem.ca",
			"homephone": "1-637-779-9586",
			"parent": "5"
		},
		{
			"ID": "37",
			"firstname": "Jena",
			"lastname": "Case",
			"email": "libero.Integer@magnaUttincidunt.net",
			"homephone": "1-725-237-4811",
			"parent": "25"
		},
		{
			"ID": "38",
			"firstname": "Raven",
			"lastname": "Puckett",
			"email": "amet.ante.Vivamus@arcuSed.co.uk",
			"homephone": "1-444-304-7292",
			"parent": "10"
		},
		{
			"ID": "39",
			"firstname": "Kameko",
			"lastname": "Valentine",
			"email": "Phasellus.fermentum.convallis@duinec.edu",
			"homephone": "1-249-351-1202",
			"parent": "82"
		},
		{
			"ID": "40",
			"firstname": "Leslie",
			"lastname": "Brennan",
			"email": "nisi@antebibendum.com",
			"homephone": "1-934-955-4531",
			"parent": "96"
		},
		{
			"ID": "41",
			"firstname": "Gray",
			"lastname": "Gentry",
			"email": "eu@aliquet.com",
			"homephone": "1-456-584-1972",
			"parent": "44"
		},
		{
			"ID": "42",
			"firstname": "Gillian",
			"lastname": "Hardin",
			"email": "vulputate.dui@montesnasceturridiculus.org",
			"homephone": "1-378-798-0298",
			"parent": "56"
		},
		{
			"ID": "43",
			"firstname": "Jelani",
			"lastname": "Castaneda",
			"email": "vitae@magnaPraesentinterdum.co.uk",
			"homephone": "1-277-992-3360",
			"parent": "14"
		},
		{
			"ID": "44",
			"firstname": "Zahir",
			"lastname": "Hewitt",
			"email": "Donec.vitae@Aenean.net",
			"homephone": "1-119-104-5156",
			"parent": "95"
		},
		{
			"ID": "45",
			"firstname": "Brent",
			"lastname": "Kirk",
			"email": "malesuada@lorem.net",
			"homephone": "1-541-252-1979",
			"parent": "22"
		},
		{
			"ID": "46",
			"firstname": "Serina",
			"lastname": "Mays",
			"email": "convallis@Phasellusdolor.edu",
			"homephone": "1-092-561-6135",
			"parent": "42"
		},
		{
			"ID": "47",
			"firstname": "Jade",
			"lastname": "Franco",
			"email": "ipsum.Curabitur.consequat@loremvitae.org",
			"homephone": "1-633-425-2782",
			"parent": "31"
		},
		{
			"ID": "48",
			"firstname": "Emerald",
			"lastname": "Flowers",
			"email": "sapien@malesuadafames.co.uk",
			"homephone": "1-650-904-4333",
			"parent": "77"
		},
		{
			"ID": "49",
			"firstname": "Kaitlin",
			"lastname": "Quinn",
			"email": "purus.mauris@eu.edu",
			"homephone": "1-608-531-8640",
			"parent": "12"
		},
		{
			"ID": "50",
			"firstname": "Doris",
			"lastname": "Young",
			"email": "et.tristique.pellentesque@mauris.net",
			"homephone": "1-411-859-3231",
			"parent": "36"
		},
		{
			"ID": "51",
			"firstname": "Chloe",
			"lastname": "Church",
			"email": "quis.diam.luctus@Cumsociisnatoque.ca",
			"homephone": "1-031-543-7405",
			"parent": "45"
		},
		{
			"ID": "52",
			"firstname": "Sandra",
			"lastname": "Hays",
			"email": "a.malesuada.id@ipsumprimis.ca",
			"homephone": "1-408-821-0312",
			"parent": "38"
		},
		{
			"ID": "53",
			"firstname": "Nadine",
			"lastname": "Stanton",
			"email": "non.sollicitudin@Aliquam.org",
			"homephone": "1-378-433-2722",
			"parent": "33"
		},
		{
			"ID": "54",
			"firstname": "Vladimir",
			"lastname": "Sharp",
			"email": "adipiscing.lacus.Ut@quispede.com",
			"homephone": "1-866-999-6846",
			"parent": "90"
		},
		{
			"ID": "55",
			"firstname": "Jackson",
			"lastname": "Carrillo",
			"email": "Duis@massa.ca",
			"homephone": "1-393-627-5055",
			"parent": "74"
		},
		{
			"ID": "56",
			"firstname": "Caldwell",
			"lastname": "Preston",
			"email": "ac.mi@liberoProin.net",
			"homephone": "1-326-895-2074",
			"parent": "11"
		},
		{
			"ID": "57",
			"firstname": "Jane",
			"lastname": "Bridges",
			"email": "est.Nunc@etarcu.net",
			"homephone": "1-157-705-8706",
			"parent": "13"
		},
		{
			"ID": "58",
			"firstname": "Lucas",
			"lastname": "Hoover",
			"email": "iaculis.lacus@arcu.net",
			"homephone": "1-558-409-8142",
			"parent": "62"
		},
		{
			"ID": "59",
			"firstname": "Hu",
			"lastname": "Valentine",
			"email": "justo.nec.ante@sodalespurusin.co.uk",
			"homephone": "1-137-398-8336",
			"parent": "47"
		},
		{
			"ID": "60",
			"firstname": "Lyle",
			"lastname": "Huff",
			"email": "eros@malesuada.com",
			"homephone": "1-223-649-0370",
			"parent": "4"
		},
		{
			"ID": "61",
			"firstname": "Christen",
			"lastname": "Whitney",
			"email": "Fusce@interdumSedauctor.org",
			"homephone": "1-538-993-5436",
			"parent": "75"
		},
		{
			"ID": "62",
			"firstname": "Piper",
			"lastname": "Simpson",
			"email": "sem.elit.pharetra@Etiam.org",
			"homephone": "1-177-877-0605",
			"parent": "40"
		},
		{
			"ID": "63",
			"firstname": "Jemima",
			"lastname": "Wolfe",
			"email": "Donec.luctus.aliquet@etnetuset.net",
			"homephone": "1-131-509-2892",
			"parent": "4"
		},
		{
			"ID": "64",
			"firstname": "Levi",
			"lastname": "Mosley",
			"email": "sed@acfermentum.edu",
			"homephone": "1-297-341-6414",
			"parent": "33"
		},
		{
			"ID": "65",
			"firstname": "Winter",
			"lastname": "Delacruz",
			"email": "eget.volutpat@eratEtiam.com",
			"homephone": "1-331-352-9232",
			"parent": "62"
		},
		{
			"ID": "66",
			"firstname": "Ezekiel",
			"lastname": "Fischer",
			"email": "Mauris.molestie.pharetra@accumsan.net",
			"homephone": "1-172-325-2405",
			"parent": "90"
		},
		{
			"ID": "67",
			"firstname": "Blossom",
			"lastname": "Valenzuela",
			"email": "Phasellus@elit.co.uk",
			"homephone": "1-341-778-9062",
			"parent": "5"
		},
		{
			"ID": "68",
			"firstname": "Myles",
			"lastname": "Bishop",
			"email": "tempor@auguemalesuada.net",
			"homephone": "1-981-140-1325",
			"parent": "44"
		},
		{
			"ID": "69",
			"firstname": "Slade",
			"lastname": "Leon",
			"email": "at.velit.Pellentesque@porttitorinterdumSed.edu",
			"homephone": "1-540-271-8832",
			"parent": "15"
		},
		{
			"ID": "70",
			"firstname": "Ursa",
			"lastname": "Warner",
			"email": "tempus@a.com",
			"homephone": "1-024-479-2375",
			"parent": "5"
		},
		{
			"ID": "71",
			"firstname": "Carla",
			"lastname": "Myers",
			"email": "non.ante@aliquetlobortisnisi.org",
			"homephone": "1-851-283-1738",
			"parent": "83"
		},
		{
			"ID": "72",
			"firstname": "Jorden",
			"lastname": "Bender",
			"email": "congue.In.scelerisque@lectuspede.ca",
			"homephone": "1-458-219-3849",
			"parent": "54"
		},
		{
			"ID": "73",
			"firstname": "Carson",
			"lastname": "Gamble",
			"email": "ullamcorper.velit@Uttincidunt.ca",
			"homephone": "1-772-260-6603",
			"parent": "25"
		},
		{
			"ID": "74",
			"firstname": "Fatima",
			"lastname": "Waller",
			"email": "Duis.volutpat.nunc@ipsumSuspendissenon.edu",
			"homephone": "1-738-223-3670",
			"parent": "9"
		},
		{
			"ID": "75",
			"firstname": "Gail",
			"lastname": "Luna",
			"email": "ac.turpis.egestas@pedeacurna.net",
			"homephone": "1-863-906-2030",
			"parent": "83"
		},
		{
			"ID": "76",
			"firstname": "Eric",
			"lastname": "Bridges",
			"email": "Proin.non@quamdignissimpharetra.co.uk",
			"homephone": "1-205-115-3644",
			"parent": "46"
		},
		{
			"ID": "77",
			"firstname": "Jonas",
			"lastname": "Byrd",
			"email": "cursus.Nunc@mollisvitae.com",
			"homephone": "1-142-551-7664",
			"parent": "57"
		},
		{
			"ID": "78",
			"firstname": "Griffith",
			"lastname": "Floyd",
			"email": "lectus.quis.massa@Integervulputaterisus.ca",
			"homephone": "1-321-866-3895",
			"parent": "32"
		},
		{
			"ID": "79",
			"firstname": "Dale",
			"lastname": "Rowe",
			"email": "Aliquam.nisl@Maecenas.com",
			"homephone": "1-178-814-2426",
			"parent": "23"
		},
		{
			"ID": "80",
			"firstname": "Carolyn",
			"lastname": "Clay",
			"email": "massa.Suspendisse@maurisSuspendisse.edu",
			"homephone": "1-989-932-2169",
			"parent": "26"
		},
		{
			"ID": "81",
			"firstname": "Liberty",
			"lastname": "Campos",
			"email": "ipsum.Donec@sit.org",
			"homephone": "1-458-710-8372",
			"parent": "71"
		},
		{
			"ID": "82",
			"firstname": "Charles",
			"lastname": "Harris",
			"email": "a.malesuada.id@velit.org",
			"homephone": "1-595-288-7920",
			"parent": "97"
		},
		{
			"ID": "83",
			"firstname": "Kitra",
			"lastname": "Logan",
			"email": "nisi.a@sitamet.com",
			"homephone": "1-405-232-3793",
			"parent": "1"
		},
		{
			"ID": "84",
			"firstname": "Mohammad",
			"lastname": "Robles",
			"email": "magna.Praesent@lobortisnisi.org",
			"homephone": "1-143-453-9170",
			"parent": "53"
		},
		{
			"ID": "85",
			"firstname": "Sigourney",
			"lastname": "Ellison",
			"email": "volutpat@Phasellusvitaemauris.com",
			"homephone": "1-158-298-8743",
			"parent": "9"
		},
		{
			"ID": "86",
			"firstname": "Bree",
			"lastname": "Rush",
			"email": "est@non.com",
			"homephone": "1-452-358-0889",
			"parent": "71"
		},
		{
			"ID": "87",
			"firstname": "Alana",
			"lastname": "Carr",
			"email": "enim.Etiam.imperdiet@ut.ca",
			"homephone": "1-973-413-4960",
			"parent": "15"
		},
		{
			"ID": "88",
			"firstname": "Connor",
			"lastname": "Douglas",
			"email": "venenatis.a@Proinultrices.org",
			"homephone": "1-392-299-2078",
			"parent": "11"
		},
		{
			"ID": "89",
			"firstname": "Olympia",
			"lastname": "Griffith",
			"email": "et@NullaaliquetProin.net",
			"homephone": "1-086-697-8146",
			"parent": "74"
		},
		{
			"ID": "90",
			"firstname": "Erin",
			"lastname": "Ayers",
			"email": "diam@sit.com",
			"homephone": "1-152-933-6631",
			"parent": "37"
		},
		{
			"ID": "91",
			"firstname": "Quintessa",
			"lastname": "Schultz",
			"email": "at.iaculis@ultricesiaculis.ca",
			"homephone": "1-297-765-0662",
			"parent": "90"
		},
		{
			"ID": "92",
			"firstname": "Todd",
			"lastname": "Howell",
			"email": "vestibulum@utmiDuis.net",
			"homephone": "1-064-478-1528",
			"parent": "7"
		},
		{
			"ID": "93",
			"firstname": "Farrah",
			"lastname": "Hammond",
			"email": "Nunc.mauris@facilisis.co.uk",
			"homephone": "1-605-334-1856",
			"parent": "49"
		},
		{
			"ID": "94",
			"firstname": "Jorden",
			"lastname": "Gray",
			"email": "cursus.non@laoreetipsumCurabitur.co.uk",
			"homephone": "1-604-885-1284",
			"parent": "39"
		},
		{
			"ID": "95",
			"firstname": "Tyrone",
			"lastname": "Graves",
			"email": "enim@arcuMorbisit.org",
			"homephone": "1-341-906-4415",
			"parent": "25"
		},
		{
			"ID": "96",
			"firstname": "Angela",
			"lastname": "Harding",
			"email": "eget.odio.Aliquam@velquamdignissim.co.uk",
			"homephone": "1-382-236-1661",
			"parent": "62"
		},
		{
			"ID": "97",
			"firstname": "Walter",
			"lastname": "Johns",
			"email": "dolor@lectusante.org",
			"homephone": "1-239-481-4206",
			"parent": "9"
		},
		{
			"ID": "98",
			"firstname": "Phillip",
			"lastname": "Mccarthy",
			"email": "dolor.dolor@nequevenenatislacus.co.uk",
			"homephone": "1-476-192-9324",
			"parent": "3"
		},
		{
			"ID": "99",
			"firstname": "Clark",
			"lastname": "Valdez",
			"email": "ante@Sedcongueelit.org",
			"homephone": "1-026-187-8414",
			"parent": "23"
		},
		{
			"ID": "100",
			"firstname": "Roth",
			"lastname": "Hernandez",
			"email": "in.lobortis@sociis.ca",
			"homephone": "1-369-609-8023",
			"parent": "85"
		}
]

let Person = Backbone.Model.extend({
    defaults: {
        id: '',
        firstname: '',
        lastname: '',
        email: '',
        homephone: '',
        parent: ''
    },

    initialize: function() {
        let self = this
        if (this.get('parent') !== '') {
            self.set('type', 'student')
        } else {
            self.set('type', 'parent')
        }
    }
})

let People = Backbone.Collection.extend({
    model: Person,

    comparator: function (person) {
        return person.get("lastname")
    }
})

let PersonView = Backbone.View.extend({
    tagName: 'li',
    attributes: function () {
        return {
            class: 'list-group-item person ' + this.model.get('type')
        }
    },
    
    events: {
        "click .list-header": "showDetails"
    },

    template: _.template($('#person-template').html()),

    render: function() {
        this.$el.html(this.template(this.model.toJSON()))
        return this
    },

    showDetails: function (e) {
        $(e.target).closest('.list-group-item').toggleClass('active')
        $(e.target).siblings('.details').slideToggle('fast')
    }
})

let PeopleView = Backbone.View.extend({
    el: '#contacts',
    initialize: function (data) {
        this.collection = new People(data)
        this.render()
    },
    render: function() {
        let self = this
        $('#contacts').empty()

        _.each(this.collection.models, function(person) {
            self.renderPerson(person)
        }, this)
    },

    renderPerson: function (person) {
        let personView = new PersonView({
            model: person
        })

        $('#contacts').append(personView.render().el)
    }
})



let AppRouter = Backbone.Router.extend({
	routes: {
		"giraffe": "giraffe"
	},

	giraffe: function () {
		alert('Giraffe')
	}
})

$(document).ready(function() {


    let peopleView = new PeopleView(directoryData)

	let router = new AppRouter()
	
	Backbone.history.start()

	router.navigate('giraffe', { trigger: true })
})

