package com.raptor.social_network;

import java.sql.Connection;
import java.sql.DriverManager;

public class Main {

	public static void main(String[] args) {
		Connection myConn = getConnection();
		
		if (myConn == null) {
			System.out.println("Connection failed!");
		} else {
			System.out.println("Connection succeeded!");
		}
	}

	private static Connection getConnection() {
		Connection myConn = null;
		
		try {
			Class.forName(org.postgresql.Driver.class.getName());
			myConn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/cbooksocial", "raptor", "raptor1");
		} catch (Exception exc) {
			exc.printStackTrace();
		}
		return myConn;
	}

}
