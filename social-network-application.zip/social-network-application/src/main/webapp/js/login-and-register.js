/**
 * 
 */
 
$(document).ready(function () {
	fillUpDate()
})

function fillUpDate() {
	fillUpYear($('#year'))
	fillUpMonth($('#month'))
	fillUpDay($('#day'))
}

function fillUpYear(selector) {
	let html = `<option selected disabled value="">Choose Year...</option>`
	for (let year = 1930; year < 2016; year++) {
		html += `<option value = "${year}">${year}</option>`
	}
	selector.html(html)
}

function fillUpMonth(selector) {
	let months = ['January', 'February', 'March', 'April',
					'May', 'June', 'July', 'August',
					'September', 'October', 'November', 'December']
	let html = `<option selected disabled value="">Choose Month...</option>`				
	for (let month of months) {
		html += `<option value = "${month}">${month}</option>`
	}
	
	selector.html(html)
}

function fillUpDay(selector) {
	let html = `<option selected disabled value="">Choose Day...</option>`
	for (let day = 1; day <= 31; day++) {
		html += `<option value = "${day}">${day}</option>`
	}
	selector.append(html)
}









