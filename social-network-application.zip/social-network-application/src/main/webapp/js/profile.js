/**
 * 
 */
 
 $(document).ready(function () {
	
	$('.list-group').children().first().addClass('selected-item')
	
	$('.list-group-item').on('click', function () {
		$(this).closest('.list-group').find('.selected-item').removeClass('selected-item')
		$(this).addClass('selected-item')
	})
	
})