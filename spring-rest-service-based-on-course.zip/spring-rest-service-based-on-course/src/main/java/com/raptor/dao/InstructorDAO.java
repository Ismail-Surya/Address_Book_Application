package com.raptor.dao;

import java.util.List;

import com.raptor.entity.Instructor;

public interface InstructorDAO {

	List <Instructor> getInstructors();
	
}
