package com.raptor.dao;

import java.util.List;


import org.hibernate.query.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.raptor.entity.Instructor;
import com.raptor.entity.InstructorDetail;

@Repository
public class InstructorDAOImpl implements InstructorDAO {

	@Autowired
	SessionFactory sessionFactory;
	
	@Override
	@Transactional
	public List<Instructor> getInstructors() {
		
		Session session = sessionFactory.openSession();
		session.getTransaction().begin();
		Query <Instructor> theQuery = session.createQuery("select distinct i from Instructor i "
									+ "JOIN FETCH i.courses c "
									+ "JOIN FETCH c.reviews",
									// + "where i.id =: theInstructorId",
				Instructor.class);
		
//		theQuery.setParameter("theInstructorId", 1);
		
		List <Instructor> instructors = theQuery.getResultList();
		
		/* Query<InstructorDetail> theQuery1 = session.createQuery("from InstructorDetail", InstructorDetail.class);
		
		List<InstructorDetail> instructorDetails = theQuery1.getResultList();
		
		System.out.println(instructorDetails);
		
		int theId = 7;
		
		Instructor theInstructor = session.get(Instructor.class, theId);
		
		System.out.println("The instructor that was retrieved using id "
								+ theId + " is " + theInstructor);
		System.out.println("Deleting it.");
		
		InstructorDetail theInstructorDetail = theInstructor.getInstructorDetail();
		
		theInstructor.setInstructorDetail(session.get(InstructorDetail.class, 4));
		
		session.delete(theInstructorDetail);
		
		Query deleteQuery = session.createQuery("delete from Instructor where id =: id");
		
		deleteQuery.setParameter("id", theId);
		
		deleteQuery.executeUpdate();
		
		session.getTransaction().commit(); */
		session.getTransaction().commit();
		
		session.close();
		return instructors;
		
	}

}
