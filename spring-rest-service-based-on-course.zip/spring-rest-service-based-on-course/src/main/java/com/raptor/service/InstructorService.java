package com.raptor.service;

import java.util.List;

import com.raptor.entity.Instructor;

public interface InstructorService {

	List <Instructor> getInstructors();
	
}
