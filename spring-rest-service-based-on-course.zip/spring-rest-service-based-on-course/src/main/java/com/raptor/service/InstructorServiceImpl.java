package com.raptor.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.raptor.dao.InstructorDAO;
import com.raptor.entity.Instructor;

@Service
public class InstructorServiceImpl implements InstructorService {

	@Autowired
	InstructorDAO instructorDAO;
	
	@Override
	public List<Instructor> getInstructors() {
		return instructorDAO.getInstructors();
	}

}
